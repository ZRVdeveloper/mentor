$('button').on('click', function(){
  $('body').toggleClass('open');
});