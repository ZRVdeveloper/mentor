A Pen created at CodePen.io. You can find this one at https://codepen.io/prvnbist/pen/GQMPZq.

 It's basically a template with couple of features like that are invoked on scroll - Shrink Header, addition of drop shadow. Other than that smooth scroll feature is also added to logo(scroll top top) and smooth scroll to section on clicking menu item.